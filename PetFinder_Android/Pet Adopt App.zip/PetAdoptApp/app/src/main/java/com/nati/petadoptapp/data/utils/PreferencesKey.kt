package com.nati.petadoptapp.data.utils

object PreferencesKey {
    const val PREF_KEY = "my_preferences"
    const val NAME_KEY = "name_key"
}
