package com.nati.petadoptapp.model.user

data class AuthenticationFirebase(
    val email: String,
    val password: String
)