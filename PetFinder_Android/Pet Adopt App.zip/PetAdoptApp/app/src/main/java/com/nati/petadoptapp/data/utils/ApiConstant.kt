package com.nati.petadoptapp.data.utils

object ApiConstant {
    const val CLIENT_ID: String = "RYHZfNQzfknAAaIzGmsh1K8z2cHX485pLWTQMDwvuyyxPDLHT9"
    const val SECRET_ID = "XkvPGumoamjFgHAxrfvYHaTr5GEaUYrLHqxpshq8"
}