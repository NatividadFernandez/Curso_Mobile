abstract class TokenRepository {
  Future createToken();
}
