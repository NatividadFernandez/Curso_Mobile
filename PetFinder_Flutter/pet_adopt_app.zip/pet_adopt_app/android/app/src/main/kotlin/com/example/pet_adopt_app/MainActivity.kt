package com.example.pet_adopt_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
